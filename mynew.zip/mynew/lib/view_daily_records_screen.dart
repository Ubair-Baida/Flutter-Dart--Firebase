import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class ViewDailyRecordsScreen extends StatefulWidget {
  @override
  _ViewDailyRecordsScreenState createState() => _ViewDailyRecordsScreenState();
}

class _ViewDailyRecordsScreenState extends State<ViewDailyRecordsScreen> {
  List<Map<String, dynamic>> dailyRecords = [];
  DateTime selectedDate = DateTime.now();

  Future<void> loadDailyRecords(DateTime date) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> expenses = prefs.getStringList('expenses') ?? [];
    List<Map<String, dynamic>> loadedRecords = expenses.map((e) {
      Map<String, dynamic> expense = json.decode(e);
      expense['date'] = DateTime.parse(expense['date']);
      return expense;
    }).toList();

    setState(() {
      dailyRecords = loadedRecords.where((record) {
        return record['date'].day == date.day &&
            record['date'].month == date.month &&
            record['date'].year == date.year;
      }).toList();
    });
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );

    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
      loadDailyRecords(picked);
    }
  }

  @override
  void initState() {
    super.initState();
    loadDailyRecords(selectedDate);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Daily Records'),
        backgroundColor: Colors.teal,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal, Colors.greenAccent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              // Date Picker Button
              ElevatedButton(
                onPressed: () => _selectDate(context),
                child: Text(
                  'Select Date: ${DateFormat('yyyy-MM-dd').format(selectedDate)}',
                  style: TextStyle(color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              SizedBox(height: 20),

              // Records List in Box Format
              dailyRecords.isNotEmpty
                  ? Expanded(
                child: ListView.builder(
                  itemCount: dailyRecords.length,
                  itemBuilder: (context, index) {
                    return Container(
                      margin: const EdgeInsets.symmetric(vertical: 8),
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black26,
                            blurRadius: 6,
                            offset: Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            dailyRecords[index]['description'],
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            'Amount: \$${dailyRecords[index]['amount'].toStringAsFixed(2)}',
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.black87,
                            ),
                          ),
                          Text(
                            'Time: ${DateFormat('hh:mm a').format(dailyRecords[index]['date'])}',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.black54,
                            ),
                          ),
                          Text(
                            'Category: ${dailyRecords[index]['category']}',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.black54,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              )
                  : Center(
                child: Text(
                  'No records found for this date.',
                  style: TextStyle(fontSize: 16, color: Colors.grey),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
