import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class ExpenseInsightsScreen extends StatefulWidget {
  @override
  _ExpenseInsightsScreenState createState() => _ExpenseInsightsScreenState();
}

class _ExpenseInsightsScreenState extends State<ExpenseInsightsScreen> {
  Map<String, double> categoryTotals = {
    'Food': 0.0,
    'Transport': 0.0,
    'Health': 0.0,
    'Other': 0.0,
  };

  @override
  void initState() {
    super.initState();
    _loadExpenses();
  }

  Future<void> _loadExpenses() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> expenses = prefs.getStringList('expenses') ?? [];

    Map<String, double> tempCategoryTotals = {
      'Food': 0.0,
      'Transport': 0.0,
      'Health': 0.0,
      'Other': 0.0,
    };

    for (String expense in expenses) {
      Map<String, dynamic> record = json.decode(expense);
      String category = record['category'];
      double amount = record['amount'];

      if (tempCategoryTotals.containsKey(category)) {
        tempCategoryTotals[category] = tempCategoryTotals[category]! + amount;
      } else {
        tempCategoryTotals['Other'] = tempCategoryTotals['Other']! + amount;
      }
    }

    setState(() {
      categoryTotals = tempCategoryTotals;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Expense Insights'),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Monthly Expense Distribution',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.teal[800],
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: PieChart(
                PieChartData(
                  sections: _generateChartSections(),
                  centerSpaceRadius: 50,
                  sectionsSpace: 2,
                ),
              ),
            ),
            SizedBox(height: 20),
            Text(
              'Insights',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.teal[800],
              ),
            ),
            SizedBox(height: 10),
            Expanded(
              child: ListView(
                children: _generateInsights(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<PieChartSectionData> _generateChartSections() {
    return categoryTotals.entries.map((entry) {
      return PieChartSectionData(
        color: _getCategoryColor(entry.key),
        value: entry.value,
        title: '${entry.key} (${entry.value.toStringAsFixed(0)})',
        titleStyle: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      );
    }).toList();
  }

  List<Widget> _generateInsights() {
    List<Widget> insights = [];
    categoryTotals.forEach((category, amount) {
      insights.add(
        ListTile(
          leading: Icon(
            Icons.circle,
            color: _getCategoryColor(category),
          ),
          title: Text(
            '$category: \$${amount.toStringAsFixed(2)}',
            style: TextStyle(fontSize: 16),
          ),
        ),
      );
    });

    return insights;
  }

  Color _getCategoryColor(String category) {
    switch (category) {
      case 'Food':
        return Colors.teal;
      case 'Transport':
        return Colors.orange;
      case 'Health':
        return Colors.blue;
      case 'Other':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }
}
