import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool isNotificationsEnabled = true;
  bool isDarkModeEnabled = false;

  void toggleNotifications(bool value) {
    setState(() {
      isNotificationsEnabled = value;
    });
  }

  void toggleDarkMode(bool value) {
    setState(() {
      isDarkModeEnabled = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            // Section Title
            Text(
              'Preferences',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Divider(),
            // Notifications Toggle
            ListTile(
              leading: Icon(Icons.notifications, color: Colors.teal),
              title: Text('Enable Notifications'),
              trailing: Switch(
                value: isNotificationsEnabled,
                onChanged: toggleNotifications,
                activeColor: Colors.teal,
              ),
            ),
            Divider(),
            // Dark Mode Toggle
            ListTile(
              leading: Icon(Icons.brightness_6, color: Colors.teal),
              title: Text('Enable Dark Mode'),
              trailing: Switch(
                value: isDarkModeEnabled,
                onChanged: toggleDarkMode,
                activeColor: Colors.teal,
              ),
            ),
            Divider(),
            // Account Settings
            Text(
              'Account Settings',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.person, color: Colors.teal),
              title: Text('Profile'),
              subtitle: Text('Edit your profile details'),
              onTap: () {
                // Navigate to profile editing screen (placeholder)
                print('Profile tapped');
              },
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.lock, color: Colors.teal),
              title: Text('Change Password'),
              subtitle: Text('Update your account password'),
              onTap: () {
                // Navigate to change password screen (placeholder)
                print('Change Password tapped');
              },
            ),
            Divider(),
            // Support Section
            Text(
              'Support',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.help_outline, color: Colors.teal),
              title: Text('Help & Support'),
              subtitle: Text('Get assistance for any issues'),
              onTap: () {
                // Navigate to help screen (placeholder)
                print('Help & Support tapped');
              },
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.info_outline, color: Colors.teal),
              title: Text('About'),
              subtitle: Text('Learn more about this app'),
              onTap: () {
                // Navigate to about screen (placeholder)
                print('About tapped');
              },
            ),
          ],
        ),
      ),
    );
  }
}
