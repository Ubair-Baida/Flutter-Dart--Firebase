import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class ViewMonthlyExpensesScreen extends StatefulWidget {
  @override
  _ViewMonthlyExpensesScreenState createState() =>
      _ViewMonthlyExpensesScreenState();
}

class _ViewMonthlyExpensesScreenState extends State<ViewMonthlyExpensesScreen> {
  double monthlyTotal = 0.0;
  List<Map<String, dynamic>> monthlyExpenses = [];

  Future<void> calculateMonthlyExpenses() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> expenses = prefs.getStringList('expenses') ?? [];
    double total = 0.0;
    List<Map<String, dynamic>> tempExpenses = [];

    for (String expense in expenses) {
      Map<String, dynamic> record = json.decode(expense);
      DateTime date = DateTime.parse(record['date']);
      if (date.month == DateTime.now().month && date.year == DateTime.now().year) {
        total += record['amount'];
        tempExpenses.add(record);
      }
    }

    setState(() {
      monthlyTotal = total;
      monthlyExpenses = tempExpenses;
    });
  }

  @override
  void initState() {
    super.initState();
    calculateMonthlyExpenses();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Monthly Expenses'),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Total Monthly Expenses:',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              '\$${monthlyTotal.toStringAsFixed(2)}',
              style: TextStyle(fontSize: 28, color: Colors.teal, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text(
              'Expense Details:',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Expanded(
              child: monthlyExpenses.isNotEmpty
                  ? ListView.builder(
                itemCount: monthlyExpenses.length,
                itemBuilder: (context, index) {
                  var expense = monthlyExpenses[index];
                  return Card(
                    margin: EdgeInsets.symmetric(vertical: 8),
                    elevation: 3,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.teal,
                        child: Icon(Icons.attach_money, color: Colors.white),
                      ),
                      title: Text(
                        expense['description'] ?? 'No Description',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        'Date: ${expense['date']}',
                        style: TextStyle(color: Colors.grey[600]),
                      ),
                      trailing: Text(
                        '\$${expense['amount'].toStringAsFixed(2)}',
                        style: TextStyle(
                            color: Colors.red, fontWeight: FontWeight.bold),
                      ),
                    ),
                  );
                },
              )
                  : Center(
                child: Text(
                  'No expenses recorded for this month.',
                  style: TextStyle(fontSize: 16, color: Colors.grey),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
