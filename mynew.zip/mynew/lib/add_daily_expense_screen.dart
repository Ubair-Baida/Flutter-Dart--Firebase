import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class AddDailyExpenseScreen extends StatefulWidget {
  @override
  _AddDailyExpenseScreenState createState() => _AddDailyExpenseScreenState();
}

class _AddDailyExpenseScreenState extends State<AddDailyExpenseScreen> {
  final TextEditingController descriptionController = TextEditingController();
  final TextEditingController amountController = TextEditingController();
  DateTime selectedDate = DateTime.now();
  String selectedCategory = 'Food'; // Default category

  List<String> categories = ['Food', 'Transport', 'Entertainment', 'Health', 'Other'];

  Future<void> saveExpense(String description, double amount, DateTime date, String category) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> expenses = prefs.getStringList('expenses') ?? [];

    Map<String, dynamic> newExpense = {
      'description': description,
      'amount': amount,
      'date': date.toIso8601String(),
      'category': category,
    };

    expenses.add(json.encode(newExpense));
    prefs.setStringList('expenses', expenses);
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    ) ?? selectedDate;

    if (picked != null && picked != selectedDate)
      setState(() {
        selectedDate = picked;
      });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Daily Expense'),
        backgroundColor: Colors.teal, // Match login screen
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal, Colors.greenAccent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Card(
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Description Field
                    TextField(
                      controller: descriptionController,
                      decoration: InputDecoration(
                        labelText: 'Description',
                        prefixIcon: Icon(Icons.description, color: Colors.teal),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                    SizedBox(height: 15),

                    // Amount Field
                    TextField(
                      controller: amountController,
                      decoration: InputDecoration(
                        labelText: 'Amount',
                        prefixIcon: Icon(Icons.attach_money, color: Colors.teal),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    SizedBox(height: 20),

                    // Category Dropdown
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.teal.withOpacity(0.5)),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12.0),
                        child: DropdownButton<String>(
                          value: selectedCategory,
                          isExpanded: true,
                          onChanged: (String? newValue) {
                            setState(() {
                              selectedCategory = newValue!;
                            });
                          },
                          items: categories.map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value, style: TextStyle(fontSize: 16, color: Colors.teal[800])),
                            );
                          }).toList(),
                          icon: Icon(Icons.arrow_drop_down, color: Colors.teal),
                        ),
                      ),
                    ),
                    SizedBox(height: 20),

                    // Date Picker Button
                    ElevatedButton(
                      onPressed: () => _selectDate(context),
                      child: Text('Select Date: ${selectedDate.toLocal()}'.split(' ')[0]),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal, // Match login screen
                        padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                    SizedBox(height: 20),

                    // Save Button
                    ElevatedButton(
                      onPressed: () async {
                        if (descriptionController.text.isNotEmpty &&
                            amountController.text.isNotEmpty &&
                            double.tryParse(amountController.text) != null) {
                          await saveExpense(
                            descriptionController.text,
                            double.parse(amountController.text),
                            selectedDate,
                            selectedCategory,
                          );
                          _showConfirmationDialog();
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Please fill all fields correctly.')),
                          );
                        }
                      },
                      child: Text('Save Expense'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal, // Match login screen
                        padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                    SizedBox(height: 20),

                    // Clear Fields Button
                    TextButton(
                      onPressed: () {
                        descriptionController.clear();
                        amountController.clear();
                        setState(() {
                          selectedCategory = 'Food';
                          selectedDate = DateTime.now();
                        });
                      },
                      child: Text('Clear Fields'),
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.teal, // Match login screen
                        textStyle: TextStyle(fontSize: 16),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Confirmation Dialog after saving expense
  void _showConfirmationDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Expense Saved!'),
          content: Text('Your expense has been successfully saved.'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pop(context); // Go back to previous screen
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }
}
